// Package stats provides statistic utilities for Plan 9.
package stats
