# plan9stats
A module for retrieving statistics of Plan 9
