# webbrowser contributing guide

Any changes are welcomed!

1. Be nice.
2. Don't be afraid to ask, but please try search first.

## Looking for contact info?

- Twitter: [@toqueteos](https://twitter.com/toqueteos)
- Mail: `toqueteos AT gmail DOT com`
