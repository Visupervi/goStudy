import XCTest

import FlatBuffers_Test_SwiftTests

var tests = [XCTestCaseEntry]()
tests += FlatBuffers_Test_SwiftTests.__allTests()

XCTMain(tests)
