<!--

Thank you for your pull request!

Please read the Code changes section of the CONTRIBUTING.md file,
and make sure you have followed the instructions.

https://github.com/pelletier/go-toml/blob/v2/CONTRIBUTING.md#code-changes

-->

Explanation of what this pull request does.

More detailed description of the decisions being made and the reasons why (if
the patch is non-trivial).

---

Paste `benchstat` results here
