package main

// @description.markdown
// @tag.name dogs
// @tag.description Dogs are cool
// @tag.name cats
// @tag.description Cats are the devil
// @tag.docs.url https://google.de
// @tag.docs.description google is super useful to find out that cats are evil!
// @tag.name apes
// @tag.description Apes are also cool
func main() {}
