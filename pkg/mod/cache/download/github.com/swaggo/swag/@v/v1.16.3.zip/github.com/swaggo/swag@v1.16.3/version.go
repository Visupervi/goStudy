package swag

// Version of swag.
const Version = "v1.16.3"
