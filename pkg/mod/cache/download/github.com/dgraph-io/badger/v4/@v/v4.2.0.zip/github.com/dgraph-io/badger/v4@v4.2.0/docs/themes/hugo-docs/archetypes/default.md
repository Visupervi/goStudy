---
title: "Some Title"
weight: 5
prev: /prev/path
next: /next/path
toc: true
---

Lorem Ipsum
