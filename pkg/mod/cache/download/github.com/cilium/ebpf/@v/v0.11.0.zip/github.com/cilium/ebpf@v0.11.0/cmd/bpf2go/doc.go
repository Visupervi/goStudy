// Program bpf2go embeds eBPF in Go.
//
// Please see the README for details how to use it.
package main
