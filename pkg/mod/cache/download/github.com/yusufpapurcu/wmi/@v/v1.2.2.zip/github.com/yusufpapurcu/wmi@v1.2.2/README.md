wmi
===

Package wmi provides a WQL interface to Windows WMI.

Note: It interfaces with WMI on the local machine, therefore it only runs on Windows.

---

NOTE: This project is no longer being actively maintained.  If you would like
to become its new owner, please contact tlimoncelli at stack over flow dot com.

---
